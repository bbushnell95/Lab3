/* 
 * File:   switch.h
 * Author: Ryan
 *
 * Created on March 7, 2016, 11:40 AM
 */

#ifndef SWITCH_H
#define	SWITCH_H

#ifdef	__cplusplus
extern "C" {
#endif

    void initSwitch();


#ifdef	__cplusplus
}
#endif

#endif	/* SWITCH_H */

