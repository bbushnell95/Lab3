/* 
 * File:   ADC.h
 * Author: Ryan
 *
 * Created on March 5, 2016, 7:57 AM
 */

#ifndef ADC_H
#define	ADC_H

void initADC();

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* ADC_H */

