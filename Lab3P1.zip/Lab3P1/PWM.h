/* 
 * File:   PWM.h
 * Author: Ryan
 *
 * Created on March 5, 2016, 8:44 AM
 */

#ifndef PWM_H
#define	PWM_H

void initPWM();

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* PWM_H */

